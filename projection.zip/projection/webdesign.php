<?php
include_once 'header/header.php';
?>
 <!--  banner images    -->
     <div id="banner" style="float:left;">
          <img src="images/website_design.jpg" height="205" width="900" >
     </div> <!-- div banner close -->
                          
<!-- Content in the web site is here -->

<div
	id="Content"
	style="background-color:#FFFFFF; width:900; height:400px; clear:both;">
	<!-- content bar are divided into for part div -->

	<div id="main_text" ; style="width: 900; padding: 5px;">
		<table border="0" cellspacing="0" cellpadding="0">
			<tbody>
				<tr>
					<td align="left" valign="top">
						<p><h1>Web Design</h1></p>
			</td>
		</tr>
        <tr>
            <td class="arialmaintext" align="left" valign="top">
            <p style="text-align:justify; margin-right:8px">
            Daa Systems provides Professional Android Applications Development service to develop Web Service based Applications , Multimedia Applications, Location Based Services, Near field Communication, Bluetooth application.
 
We provide Android Application Development Services to clients worldwide.
We are dedicated to delivering Android OS App that works on  all screen resolution and support all major android platform. Our team enjoys multiple year experience in android sdks and development tools. 
Daasys never releases any product before testing it in real word scenario. 

We are based in India and our business office in USA.
 
If you have concept and would like to develop mobile app, We can surely do it for you at very reasonable cost.
 
To know what Daa Systems can do for you email us at sales@daasys.com

If you are looking for temp work then you are at right spot, we offer developers on monthly, hours and projects basis with highly reasonable price. 
            </p>
            </td>
             
        </tr>
		
		<tr>
			<td>
			<h2>Following are the areas of our expertise:</h2>
			</td>
			
		</tr>
		<tr>
			<td class="arialmaintext" align="left" valign="top">
			<ul style="margin-top: -5px; ">
				<li>Business Applications: stand alone or integrated (in the areas of Manufacturing, Financial Services, Retail, Education, Healthcare, Government etc.)</li>
				<li>E-Business Applications.</li>
				<li>Legacy & Client/Server Applications.</li>
				<li>Systems Software.</li>
				<li>Software Products.</li>
			</ul>
			</td>
		</tr>
        </tbody>
    </table>
		  
</div> <!-- div main_text close -->       
      
	<?php 
		include_once 'footer/footer-menu.php';
		include_once 'footer/footer.php';
	?>
		
						
						</div>
	<!-- master div close -->
	</body>
	</html>

<?php
include_once 'header/header.php';
?>
<!-- banner stars from here   -->
<div id="banner">
	<img src="images/banner.jpg" style="width: 900px; height: 225px;">
</div>
<!-- banner div close-->

<!-- Content of the site is here-->


<div
	id="Content" style="background-color: black; width: 900; clear: both;">
	<!-- content bar are divided into for part div -->


	<!-- frist div starts from here -->
	<div id="content_bar"
		style="background-color: yellow; width: 215px; height: 145px; float: left; padding: 5px;">
		<div id="bar_img" style="float: left;">
			<img src="images/iphone.png" width=70px; height=100px; />
		</div>
		<!-- div bar_img close -->

		<div id="bar_uptext" style="width: 130px; height: 40px; float: right;">
			<a href="iphone.php" style="text-decoration: none;">iPhone App Dev</a>
		</div>
		<!-- div bar_uptext close -->


		<div id="bar_downtext"
			style="width: 130px; height: 70px; float: right;">Enterprise
			applications across all mobile platforms.</div>
		<!-- div bar_downtext close -->

	</div>
	<!-- div content_bar close -->

	<!-- first div end from here -->


	<!-- second div starts from here -->
	<div id="content_bar"
		style="background-color: yellow; width: 215px; height: 145px; float: left; padding: 5px;">
		<div id="bar_img" style="float: left;">
			<img src="images/android.png" width=70px; height=100px; />
		</div>
		<!-- div bar_img close -->

		<div id="bar_uptext" style="width: 130px; height: 40px; float: right;">
			<a href="android.php" style="text-decoration: none;">Android App Dev</a>
		</div>
		<!-- div bar_uptext close -->

		<div id="bar_downtext"
			style="width: 130px; height: 70px; float: right;">Get infinite
			resources and infrastructure at your disposal.</div>
		<!-- div bar_downtext close -->
	</div>
	<!-- div content_bar close -->
	<!-- second div end from here -->


	<!-- Third div starts from here -->
	<div id="content_bar"
		style="background-color: yellow; width: 215px; height: 145px; float: left; padding: 5px;">
		<div id="bar_img" style="float: left;">
			<img src="images/cloud.png" width=70px; height=100px; />
		</div>
		<div id="bar_uptext" style="width: 130px; height: 40px; float: right;">
			<a href="cloud.php" style="text-decoration: none;"> Cloud </a>
		</div>

		<div id="bar_downtext"
			style="width: 130px; height: 70px; float: right;">Development
			Experience in Cloud based Project Management,</div>
		<!-- div bar_downtext close -->

	</div>
	<!-- div content_bar close -->

	<!-- Third div end from here -->


	<!-- forth div starts from here -->
	<div id="content_bar"
		style="background-color: yellow; width: 215px; height: 145px; float: left; padding: 5px;">
		<div id="bar_img" style="float: left;">
			<img src="images/web.png" width=80px; height=100px; />
		</div>
		<div id="bar_uptext" style="width: 130px; height: 40px; float: right;">
			<a href="webdesign.php" style="text-decoration: none;">Web Design</a>
		</div>

		<div id="bar_downtext"
			style="width: 130px; height: 70px; float: right;">Business Analysts
			reduce burden on your product management team.</div>
	</div>
	<!-- div content_bar close -->
	<!-- forth div end from here -->


</div>
<!--Content div close here -->
<?php 
include_once 'footer/footer.php';
?>
</div>
<!-- master div close -->
</body>
</html>

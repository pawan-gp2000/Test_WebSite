
<footer>

	<div>


		<div id="part1"
			style="background-color: #F0000F; width: 225px; height: 180px; float: left;">
			<div id="heading"
				style="background-color: #202020; width: 225px; height: 35px">

				<h id="footer_top";>

				<center>Software Development</center>
				</h>
			</div>
			<!-- div heading close -->
			<div id="text"
				style="background-color: #E0DFDF; width: 225px; height: 145px">
				<a href="#" style="text-decoration: none;">Application Development</a><br>
				<a href="#" style="text-decoration: none;">Maintenance and
					Enhancement</a><br> <a href="#" style="text-decoration: none;">Staff
					Augmentation</a>

			</div>
			<!-- div text close -->
		</div>
		<!-- div part1 close -->

		<!-- div part2 starts from here -->

		<div id="part2"
			style="background-color: #F9999F; width: 225px; height: 180px; float: left;">
			<div id="heading"
				style="background-color: #2A2929; width: 225px; height: 35px">

				<h id="footer_top";>

				<center>Mobile Application</center>
				</h>
			</div>
			<!-- div heading close -->
			<div id="text"
				style="background-color: #E0DFDF; width: 225px; height: 145px">
				<a href="#" style="text-decoration: none;">Mobile Application
					Development</a><br> <a href="#" style="text-decoration: none;">Android
					Application Development</a><br> <a href="#"
					style="text-decoration: none;">iPhone Application Development</a><br>

			</div>
			<!-- div text close -->
		</div>
		<!-- div part2 close -->



		<div id="part3"
			style="background-color: #F01111; width: 225px; height: 180px; float: left;">
			<div id="heading"
				style="background-color: #202020; width: 225px; height: 35px">

				<h id="footer_top";>
				<center>Web Development
				
				</h>
				</center>
			</div>
			<div id="text"
				style="background-color: #E0DFDF; width: 225px; height: 145px">
				<a href="#" style="text-decoration: none;">Web Application
					Development</a><br> <a href="#" style="text-decoration: none;">Maintanence
					and support</a>
			</div>
		</div>

		<div id="part4"
			style="background-color: #F55555; width: 225px; height: 180px; float: left;">
			<div id="heading"
				style="background-color: #2A2929; width: 225px; height: 35px">

				<h id="footer_top";>
				<center>Events
				
				</h>
				</center>
			</div>
			<div id="text"
				style="background-color: #E0DFDF; width: 225px; height: 145px">
				<a href="#" style="text-decoration: none;">Facebook</a><br> <a
					href="#" style="text-decoration: none;">Twitter</a>
			</div>
		</div>

</footer>

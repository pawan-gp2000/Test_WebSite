
<!-- footer starts from here -->

<footer>
	<div id="Copyright"; style="background-color: #999999; width: 900px; height: 35px; float: right; line-height: 5px">
		<p>
		<center>Copyright 1999-2012 by Daa Sys. All Rights Reserved.</center>
		</p>
	</div>
</footer>

<!--footer end from here -->


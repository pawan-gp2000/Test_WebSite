<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Header</title>
</head>
<body>
	<!--  header content -->
	<div id="master" style="width: 900px; margin: 0 auto">


		<!-- Header starts from here -->
		<div id="header"
			style="background-color: #00FF00; width: 900px; height: 130px;">
			<div id="upper_bar"
				style="background-color: #F1ECEC; width: 900px; height: 50px;">
				<div id="upper_menu">
					<ul
						style="padding-top: 3px; text-align: right; padding-right: 5px;">
						<a href="aboutus.php" style="text-decoration: none;">About Us |</a>
						<a href="career.php" style="text-decoration: none;">Career | </a>
						<a href="contactus.php" style="text-decoration: none;">Contact Us
						</a>
					</ul>
				</div>
				<!-- upper_menu close here -->
			</div>
			<!-- upper_bar close here -->
			<div id="down_bar"
				style="background-color: #F3EEEE; width: 900px; height: 80px; float: left;">

				<div id="daa"
					style="float: left; margin-top: -15px; margin-left: 5px">
					<p style="font-size: 26px;">Daa Systems</p>
				</div>
				<!-- daa div close-->

				<div id="down_menu" style="float: right;">
					<ul>
						<a href="index.php" style="text-decoration: none;">Home</a> &nbsp;
						&nbsp;
						<a href="#" style="text-decoration: none;">Web 3.0</a>&nbsp;
						&nbsp;
						<a href="#" style="text-decoration: none;">Mobile Technolgies</a>&nbsp;
						&nbsp;
						<a href="" style="text-decoration: none;">Engagement Model</a>
						&nbsp; &nbsp;
					</ul>

				</div>
				<!-- down_menu close here -->
			</div>
			<!-- down_bar div close   -->
		</div>
		<!-- Header Ends from here -->